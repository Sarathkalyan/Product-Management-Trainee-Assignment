package main

import (
	"fmt"
	"net/http"
	"time"
)

func main() {
	// Define the IST timezone
	ist, err := time.LoadLocation("Asia/Kolkata")
	if err != nil {
		fmt.Println("Error loading timezone:", err)
		return
	}

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		// Get the current time in IST
		currentTime := time.Now().In(ist).Format(time.RFC1123)
		fmt.Fprintf(w, "Current Date & Time: %s", currentTime)
	})

	http.ListenAndServe(":8080", nil)
}
